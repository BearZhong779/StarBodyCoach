import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ProgressChartProps {
  data: Array<{
    day: string;
    duration: number;
    calories: number;
  }>;
}

export function ProgressChart({ data }: ProgressChartProps) {
  const maxDuration = Math.max(...data.map(d => d.duration), 60);
  
  const dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const weekDays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  
  // Create complete week data with placeholders for missing days
  const completeWeekData = dayOrder.map((day, index) => {
    const existing = data.find(d => d.day === day);
    return {
      day: weekDays[index],
      duration: existing?.duration || 0,
      calories: existing?.calories || 0,
      completed: !!existing
    };
  });

  return (
    <Card className="bg-gray-50">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-800">本周训练记录</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-end justify-between h-32 space-x-2">
          {completeWeekData.map((item, index) => {
            const height = item.duration > 0 ? Math.max((item.duration / maxDuration) * 100, 20) : 20;
            const barColor = item.completed 
              ? index % 2 === 0 ? 'bg-blue-500' : 'bg-emerald-500'
              : 'bg-gray-300';
            
            return (
              <div key={item.day} className="flex flex-col items-center flex-1">
                <div 
                  className={`${barColor} w-full rounded-t-lg mb-2 transition-all duration-300`}
                  style={{ height: `${height}%` }}
                  title={item.completed ? `${item.duration}分钟, ${item.calories}卡路里` : '未完成'}
                />
                <span className="text-xs text-gray-600">{item.day}</span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
