import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Camera, Upload, Loader2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PhotoUploadProps {
  userId: number;
  onAnalysisComplete?: () => void;
}

export function PhotoUpload({ userId, onAnalysisComplete }: PhotoUploadProps) {
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const analyzePhotoMutation = useMutation({
    mutationFn: async (photoData: string) => {
      const response = await apiRequest("POST", "/api/body-analysis", {
        userId,
        photoUrl: photoData,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/body-analysis"] });
      toast({
        title: "分析完成！",
        description: "已找到你的明星体型匹配",
      });
      onAnalysisComplete?.();
    },
    onError: () => {
      toast({
        title: "分析失败",
        description: "请重试或检查照片质量",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    
    try {
      // Simulate file processing
      const reader = new FileReader();
      reader.onload = async (e) => {
        const photoData = e.target?.result as string;
        
        // Simulate processing delay
        setTimeout(() => {
          analyzePhotoMutation.mutate(photoData);
          setUploading(false);
        }, 2000);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      setUploading(false);
      toast({
        title: "上传失败",
        description: "请检查文件格式并重试",
        variant: "destructive",
      });
    }
  };

  const triggerFileInput = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.capture = "environment";
    input.onchange = handleFileUpload;
    input.click();
  };

  if (uploading || analyzePhotoMutation.isPending) {
    return (
      <Card className="bg-gradient-to-br from-blue-50 to-emerald-50 border-2 border-dashed border-blue-300">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">正在分析...</h3>
          <p className="text-gray-600 text-sm">AI正在分析你的体型特征</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-emerald-50 border-2 border-dashed border-blue-300">
      <CardContent className="p-8 text-center">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Camera className="h-8 w-8 text-blue-500" />
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-2">拍摄或上传照片</h3>
        <p className="text-gray-600 text-sm mb-4">全身照效果最佳</p>
        <Button 
          onClick={triggerFileInput}
          className="bg-blue-500 hover:bg-blue-600 text-white"
        >
          <Camera className="mr-2 h-4 w-4" />
          开始拍照
        </Button>
      </CardContent>
    </Card>
  );
}
