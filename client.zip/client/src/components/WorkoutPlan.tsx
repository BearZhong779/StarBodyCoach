import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dumbbell, Play, Heart, Leaf, Flame } from "lucide-react";
import type { WeeklyWorkout } from "@/lib/types";

interface WorkoutPlanProps {
  bodyType: string;
  onStartPlan: () => void;
}

export function WorkoutPlan({ bodyType, onStartPlan }: WorkoutPlanProps) {
  const getWorkoutsByBodyType = (type: string): WeeklyWorkout[] => {
    const workoutPlans = {
      "优雅纤细型": [
        {
          week: 1,
          title: "第一周 - 基础塑形",
          workouts: [
            {
              id: "pilates",
              name: "普拉提核心训练",
              duration: 30,
              difficulty: "初级难度",
              type: "核心训练",
              schedule: "周一、三、五",
              icon: "dumbbell",
              color: "blue"
            },
            {
              id: "cardio",
              name: "轻度有氧运动",
              duration: 25,
              difficulty: "中级难度",
              type: "有氧运动",
              schedule: "周二、四、六",
              icon: "heart",
              color: "emerald"
            },
            {
              id: "yoga",
              name: "瑜伽拉伸",
              duration: 20,
              difficulty: "放松恢复",
              type: "拉伸",
              schedule: "每日",
              icon: "leaf",
              color: "violet"
            }
          ]
        },
        {
          week: 2,
          title: "第二周 - 进阶雕刻",
          workouts: [
            {
              id: "ballet",
              name: "芭蕾塑形训练",
              duration: 35,
              difficulty: "中级难度",
              type: "塑形",
              schedule: "周一、三、五",
              icon: "play",
              color: "amber"
            },
            {
              id: "hiit",
              name: "HIIT间歇训练",
              duration: 20,
              difficulty: "高强度",
              type: "燃脂",
              schedule: "周二、四、六",
              icon: "fire",
              color: "red"
            }
          ]
        }
      ],
      "活力运动型": [
        {
          week: 1,
          title: "第一周 - 燃脂启动",
          workouts: [
            {
              id: "cardio-intense",
              name: "高强度有氧",
              duration: 40,
              difficulty: "中高难度",
              type: "燃脂",
              schedule: "周一、三、五",
              icon: "heart",
              color: "red"
            },
            {
              id: "strength",
              name: "力量训练",
              duration: 35,
              difficulty: "中级难度",
              type: "力量",
              schedule: "周二、四、六",
              icon: "dumbbell",
              color: "blue"
            }
          ]
        },
        {
          week: 2,
          title: "第二周 - 强化提升",
          workouts: [
            {
              id: "circuit",
              name: "循环训练",
              duration: 45,
              difficulty: "高难度",
              type: "综合",
              schedule: "周一、三、五",
              icon: "fire",
              color: "amber"
            }
          ]
        }
      ]
    };

    return workoutPlans[type as keyof typeof workoutPlans] || workoutPlans["优雅纤细型"];
  };

  const getIconComponent = (iconName: string) => {
    const icons = {
      dumbbell: Dumbbell,
      heart: Heart,
      leaf: Leaf,
      play: Play,
      fire: Flame
    };
    const Icon = icons[iconName as keyof typeof icons] || Dumbbell;
    return Icon;
  };

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-50 text-blue-600 bg-blue-100",
      emerald: "bg-emerald-50 text-emerald-600 bg-emerald-100",
      violet: "bg-violet-50 text-violet-600 bg-violet-100",
      amber: "bg-amber-50 text-amber-600 bg-amber-100",
      red: "bg-red-50 text-red-600 bg-red-100"
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const workoutWeeks = getWorkoutsByBodyType(bodyType);
  const planName = bodyType === "优雅纤细型" ? "优雅纤细塑形计划" : `${bodyType}专属计划`;

  return (
    <Card className="bg-white shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-violet-500 to-purple-600 text-white p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xl font-bold">{planName}</h3>
          <span className="bg-white/20 px-3 py-1 rounded-full text-sm">14天</span>
        </div>
        <p className="text-white/90 text-sm">专为{bodyType}设计，重点塑形和线条雕刻</p>
      </div>

      <CardContent className="p-6">
        {workoutWeeks.map((week) => (
          <div key={week.week} className="mb-6">
            <h4 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
              <span className={`${week.week === 1 ? 'bg-blue-100 text-blue-600' : 'bg-emerald-100 text-emerald-600'} w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-3`}>
                {week.week}
              </span>
              {week.title}
            </h4>
            
            <div className="space-y-3">
              {week.workouts.map((workout) => {
                const Icon = getIconComponent(workout.icon);
                const colorClass = getColorClasses(workout.color);
                const [bgColor, textColor, iconBg] = colorClass.split(' ');
                
                return (
                  <div key={workout.id} className={`flex items-center p-3 ${bgColor} rounded-lg`}>
                    <div className={`w-10 h-10 ${iconBg} rounded-lg flex items-center justify-center mr-3`}>
                      <Icon className={`h-5 w-5 ${textColor}`} />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-semibold text-gray-800">{workout.name}</h5>
                      <p className="text-gray-600 text-sm">{workout.duration}分钟 • {workout.difficulty}</p>
                    </div>
                    <span className={`${textColor} font-semibold text-sm`}>{workout.schedule}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        <Button 
          onClick={onStartPlan}
          className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white py-4 text-lg font-semibold"
        >
          开始训练计划
        </Button>
      </CardContent>
    </Card>
  );
}
