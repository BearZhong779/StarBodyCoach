import { useLocation } from "wouter";
import { Home, Camera, Dumbbell, BarChart3, User } from "lucide-react";

export function BottomNav() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "首页" },
    { path: "/analysis", icon: Camera, label: "分析" },
    { path: "/workout", icon: Dumbbell, label: "训练" },
    { path: "/progress", icon: BarChart3, label: "进度" },
    { path: "/profile", icon: User, label: "我的" },
  ];

  return (
    <nav className="bg-white border-t border-gray-200 p-4 fixed bottom-0 left-0 right-0 max-w-md mx-auto">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className={`flex flex-col items-center ${
                isActive ? "text-blue-500" : "text-gray-400"
              }`}
            >
              <Icon className="h-5 w-5 mb-1" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
